import beans.StudentBean;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import db.DBManager;

import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;

public class ModifyStudentServlet extends HttpServlet {
    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        StudentBean oldS = new StudentBean();
        StudentBean newS = new StudentBean();

        // Old values
        oldS.setNume(request.getParameter("oldNume"));
        oldS.setPrenume(request.getParameter("oldPrenume"));
        oldS.setVarsta(Integer.parseInt(request.getParameter("oldVarsta")));

        // New values
        newS.setNume(request.getParameter("nume"));
        newS.setPrenume(request.getParameter("prenume"));
        newS.setVarsta(Integer.parseInt(request.getParameter("varsta")));

        try
        {
            DBManager.update(oldS, newS);
        }
        catch (SQLException | ClassNotFoundException e)
        {
            response.sendError(404, "Eroare la moficare: " + e.getMessage());
            return;
        }

        request.setAttribute("text", "Studentul a fost modificat cu succes.");
        request.getRequestDispatcher("./read-student").forward(request, response);
    }
}