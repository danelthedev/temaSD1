import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import beans.StudentBean;
import db.DBManager;

public class ReadStudentServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try
        {
            // Read students
            List<StudentBean> l = DBManager.read();
            // Register new list
            request.setAttribute("list", l);
        }
        catch (SQLException | ClassNotFoundException e)
        {
            response.sendError(404, "Eroare la citire: " + e.getMessage());
            return;
        }

        // Check for previous messages, or add a new one
        if (request.getAttribute("text") == null)
            request.setAttribute("text", "Studentii inregistrati:");

        // redirectionare date catre pagina de afisare a informatiilor studentului
        request.getRequestDispatcher("./info-student.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        doGet(request, response);
    }
}
