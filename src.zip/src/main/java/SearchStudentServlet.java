import beans.StudentBean;
import db.DBManager;

import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

public class SearchStudentServlet extends HttpServlet {
    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        try
        {
            // Create search option student
            StudentBean opt = new StudentBean();
            opt.setNume(request.getParameter("nume"));
            opt.setPrenume(request.getParameter("prenume"));
            try
            {
                opt.setVarsta(Integer.parseInt(request.getParameter("varsta")));
            }
            catch (NumberFormatException e)
            {
                opt.setVarsta(0);
            }

            // Read students
            List<StudentBean> l = DBManager.read(opt);
            // Register new list
            request.setAttribute("list", l);
        }
        catch (SQLException | ClassNotFoundException e)
        {
            response.sendError(404, "Eroare la citire: " + e.getMessage());
            return;
        }

        // Check for previous messages, or add a new one
        request.setAttribute("text", "Studentii gasiti in urma cautarii:");

        // redirectionare date catre pagina de afisare a informatiilor studentului
        request.getRequestDispatcher("./info-student.jsp").forward(request, response);
    }
}