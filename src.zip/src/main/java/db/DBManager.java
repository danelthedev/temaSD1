package db;

import java.util.ArrayList;
import java.util.List;
import java.sql.*;
import java.util.Objects;

import beans.StudentBean;

public class DBManager {
    private static final String url = "jdbc:sqlite:C:/Users/Danel/Desktop/TemaSD/src/main/resources/studenti.db";
    private static Connection con;
    private static String selectCondition = "";
    private static Statement getConnection()
            throws SQLException, ClassNotFoundException
    {
        // Get connection
        Class.forName("org.sqlite.JDBC");
        con = DriverManager.getConnection(url);

        // return statement
        return con.createStatement();
    }

    private static void closeConnection()
            throws SQLException
    {
        con.close();
    }

    public static List<StudentBean> read()
            throws SQLException, ClassNotFoundException
    {
        List<StudentBean> l = new ArrayList<>();
        Statement statement = getConnection();
        StudentBean s;

        // Execute select query
        ResultSet rs = statement.executeQuery("SELECT * FROM studenti");

        // Set student bean values
        while(rs.next())
        {
            // Create new student from read values
            s = new StudentBean();
            s.setNume(rs.getString("nume"));
            s.setPrenume(rs.getString("prenume"));
            s.setVarsta(rs.getInt("varsta"));

            l.add(s);
        }

        // Close connection
        closeConnection();

        return l;
    }

    public static List<StudentBean> read(StudentBean opt)
            throws SQLException, ClassNotFoundException {
        // Create condition, based on opt fields. If filed is empty, condition is ignored

        int conditionNr = 0;
        if (!Objects.equals(opt.getNume(), "") && !Objects.equals(opt.getNume(), null))
        {
            selectCondition += "nume='" + opt.getNume() + "'";
            ++conditionNr;
        }
        if (!Objects.equals(opt.getPrenume(), "") && !Objects.equals(opt.getPrenume(), null))
        {
            if (conditionNr != 0)
                selectCondition += " AND ";
            selectCondition += "prenume='" + opt.getPrenume() + "'";
            ++conditionNr;
        }
        if (opt.getVarsta() != 0 )
        {
            if (conditionNr != 0)
                selectCondition += " AND ";
            selectCondition += "varsta=" + opt.getVarsta();
            ++conditionNr;
        }

        if (conditionNr != 0)
        {
            selectCondition = "SELECT * FROM studenti WHERE " + selectCondition + ";";
        }

        List<StudentBean> l = new ArrayList<>();
        Statement statement = getConnection();
        StudentBean s;

        // Execute select query
        ResultSet rs = statement.executeQuery(selectCondition);

        // Set student bean values
        while(rs.next())
        {
            // Create new student from read values
            s = new StudentBean();
            s.setNume(rs.getString("nume"));
            s.setPrenume(rs.getString("prenume"));
            s.setVarsta(rs.getInt("varsta"));

            l.add(s);
        }

        // Close connection
        closeConnection();

        // Recreate condition string, so that it does not affect normal read (not the greatest implementation)
        selectCondition = "";

        return l;
    }

    public static void add(StudentBean s)
            throws SQLException, ClassNotFoundException
    {
        Statement statement = getConnection();

        // Add new student
        statement.executeUpdate("INSERT INTO studenti VALUES ('" +
                s.getNume() + "', '" + s.getPrenume() + "', " + s.getVarsta() + ");" );
        closeConnection();
    }

    public static void update(StudentBean oldS, StudentBean newS)
            throws SQLException, ClassNotFoundException
    {
        Statement statement = getConnection();

        // Update current student
        statement.executeUpdate("UPDATE studenti SET " +
                "nume='" + newS.getNume() + "', " +
                "prenume='" + newS.getPrenume() + "', " +
                "varsta=" + newS.getVarsta() + " " +
                "WHERE " +
                "nume='" + oldS.getNume() + "' AND " +
                "prenume='" + oldS.getPrenume() + "' AND " +
                "varsta=" + oldS.getVarsta() + ";");

        closeConnection();
    }

    public static void delete(StudentBean oldS)
            throws SQLException, ClassNotFoundException
    {
        Statement statement = getConnection();

        // Update current student
        statement.executeUpdate("DELETE FROM studenti WHERE " +
                "nume='" + oldS.getNume() + "' AND " +
                "prenume='" + oldS.getPrenume() + "' AND " +
                "varsta=" + oldS.getVarsta() + ";");

        closeConnection();
    }
}
