import beans.StudentBean;
import db.DBManager;

import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;

public class DeleteStudentServlet extends HttpServlet {
    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {

        StudentBean oldS = new StudentBean();
        oldS.setNume(request.getParameter("nume"));
        oldS.setPrenume(request.getParameter("prenume"));
        oldS.setVarsta(Integer.parseInt(request.getParameter("varsta")));

        try
        {
            DBManager.delete(oldS);
        }
        catch (SQLException | ClassNotFoundException e)
        {
            response.sendError(404, "Eroare la stergere: " + e.getMessage());
            return;
        }

        request.setAttribute("text", "Studentul fost sters cu succes.");
        request.getRequestDispatcher("./read-student").forward(request, response);
    }
}