import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;

import com.google.gson.Gson;
import db.DBManager;

public class ExportJSONServlet extends HttpServlet {
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {

        try
        {
            String json = new Gson().toJson(DBManager.read());
            FileWriter f = new FileWriter("C:/Users/Danel/Desktop/TemaSD/src/main/resources/studenti.json");
            f.write(json);
            f.close();
        }
        catch (SQLException | ClassNotFoundException e)
        {
            response.sendError(404, "Eroare la export: " + e.getMessage());
            return;
        }

        request.setAttribute("text", "Fisier creat cu succes.");
        request.getRequestDispatcher("./read-student").forward(request, response);
    }
}