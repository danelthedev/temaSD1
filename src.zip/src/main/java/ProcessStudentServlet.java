import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import java.io.IOException;

import beans.StudentBean;
import db.DBManager;


public class ProcessStudentServlet extends HttpServlet {
    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // se citesc parametrii din cererea de tip POST
        StudentBean s = new StudentBean();
        s.setNume(request.getParameter("nume"));
        s.setPrenume(request.getParameter("prenume"));
        s.setVarsta(Integer.parseInt(request.getParameter("varsta")));

        try
        {
            DBManager.add(s);
        }
        catch (SQLException | ClassNotFoundException e)
        {
            response.sendError(404, "Eroare la adaugare: " + e.getMessage());
            return;
        }

        request.setAttribute("text", "Studentul a fost introdus cu succes.");
        request.getRequestDispatcher("./read-student").forward(request, response);
    }
}